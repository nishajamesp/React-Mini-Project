import React from 'react';
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Header from './components/Header';
import Footer from './components/Footer';
import RecipeDetails from "./pages/RecipeDetails";
import Favourites from './pages/Favourites';

const App = () => {
  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/recipe/:id" element={<RecipeDetails />} />
          <Route path="/favorites" element={<Favourites />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}

export default App;