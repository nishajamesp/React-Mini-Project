import { useDispatch } from "react-redux";
import { setSearchTerm } from "../redux/recipeSlice";

function FilterBar() {
  const dispatch = useDispatch();

  return (
    <div className="max-w-7xl mx-auto px-6 py-6">
      <input
        type="text"
        placeholder="Search recipes..."
        onChange={(e) => dispatch(setSearchTerm(e.target.value))}
        className="w-full md:w-1/2 px-5 py-3 border rounded-lg"
      />
    </div>
  );
}

export default FilterBar;
