import { Link } from "react-router-dom";

function Header() {
  return (
    <header className="bg-orange-500 shadow-md">
      <div className="max-w-7xl mx-auto flex justify-between items-center px-6 py-4">

        <h1 className="text-2xl font-bold text-white tracking-wide">
          🍽 RecipeHub
        </h1>

        <nav className="flex gap-8 text-white font-medium">
          <Link to="/" className="hover:text-yellow-200 transition">
            Home
          </Link>

          <Link to="/favourites" className="hover:text-yellow-200 transition">
            Favorites
          </Link>
        </nav>

      </div>
    </header>
  );
}

export default Header;
