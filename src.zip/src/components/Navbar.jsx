import React from 'react';
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div>
        <div className='brand'>Recipe Sharing Platform</div>
        <div>
        <Link to="/">Home</Link>
        <Link to="/favorites">Favorites</Link> 
      </div>

    </div>
    
  )
}

export default Navbar;