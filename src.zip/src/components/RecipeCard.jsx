import { useDispatch } from "react-redux";
import { addFavourite } from "../redux/favouriteSlice";
import { FaHeart, FaStar } from "react-icons/fa";

function RecipeCard({ recipe }) {
  const dispatch = useDispatch();

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">

      <img
        src={recipe.image}
        alt={recipe.name}
        className="w-full h-48 object-cover"
      />

      <div className="p-4">

        <h3 className="text-lg font-bold">
          {recipe.name}
        </h3>

        <div className="flex items-center text-yellow-400 my-2">
          <FaStar />
          <span className="ml-2">{recipe.rating}</span>
        </div>

        <button
          onClick={() => dispatch(addFavourite(recipe))}
          className="bg-orange-500 text-white px-4 py-2 rounded-lg flex items-center gap-2"
        >
          <FaHeart />
          Favourite
        </button>

      </div>

    </div>
  );
}

export default RecipeCard;
