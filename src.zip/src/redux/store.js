import { configureStore } from "@reduxjs/toolkit";
import recipeReducer from "./recipeSlice";
import favouriteReducer from "./favouriteSlice";

export const store = configureStore({
  reducer: {
    recipes: recipeReducer,
    favourites: favouriteReducer,
  },
});
