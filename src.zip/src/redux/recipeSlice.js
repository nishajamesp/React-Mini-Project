import { createSlice } from "@reduxjs/toolkit";
import recipesData from "../data/recipes";

const recipeSlice = createSlice({
  name: "recipes",
  initialState: {
    recipes: recipesData,
    filteredRecipes: recipesData,
  },

  reducers: {
    setSearchTerm: (state, action) => {
      const term = action.payload.toLowerCase();

      state.filteredRecipes = state.recipes.filter((recipe) =>
        recipe.name.toLowerCase().includes(term)
      );
    },
  },
});

export const { setSearchTerm } = recipeSlice.actions;
export default recipeSlice.reducer;
