import { useSelector } from "react-redux";
import RecipeCard from "../components/RecipeCard";

function Favourites() {

  const favourites = useSelector(
    (state) => state.favourites.items
  );

  return (
    <div className="bg-gray-100 min-h-screen px-6 py-10">

      <h2 className="text-3xl font-bold mb-8 text-center">
        ❤️ Your Favorite Recipes
      </h2>

      <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

        {favourites.map((recipe) => (
          <RecipeCard key={recipe.id} recipe={recipe} />
        ))}

      </div>

    </div>
  );
}

export default Favourites;
